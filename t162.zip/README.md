# Convx Sync — Listen Together server

Cloudflare Worker + Durable Objects. One Durable Object per room code; that
object owns membership, host, playback position and the queue, so there is
never a second server with a different opinion about the same room.

## Deploy

### Wispbyte / any Node host

The repository includes a Node runtime for hosts such as Wispbyte:

```bash
npm install
npm start
```

The Node API entry point is plain JavaScript at `src/node-server.js`, so hosts
that do not support `tsx` can start it directly:

```bash
cd /home/container/listen-together-server
npm install
node src/node-server.js
```

Set `PORT` when the host provides one. Set the `API_KEY` secret to protect both
the HTTP API and WebSocket upgrade, and set `PUBLIC_URL` if you want the startup
log to print the public hostname instead of localhost. On boot the process prints the
HTTP API URL, WebSocket URL, and Blends API URL.

### Discord management bot

The Node runtime can optionally start a Discord slash-command bot for API
management. Create a Discord application with a bot user, enable the
`applications.commands` scope when inviting it, and configure these values as
Replit Secrets/environment variables:

| Var | Required | Meaning |
|---|---|---|
| `DISCORD_BOT_TOKEN` | yes | Discord bot token; keep it in Replit Secrets |
| `DISCORD_ADMIN_USER_IDS` | fallback | Comma-separated IDs if not set in `config.json` |
| `DISCORD_GUILD_ID` | fallback | Guild ID if not set in `config.json` |

For simple setup, copy `config.example.json` to `config.json` and edit the
guild ID and admin user IDs. The checked-out Node workflow already reads
`config.json`; `CONVX_CONFIG_PATH` can point to a different file. The JSON only
stores the names of secret variables (`API_KEY` and `DISCORD_BOT_TOKEN`), never
their values.

The bot is disabled safely when the token or admin allowlist is missing. It
registers these ephemeral, admin-only commands:

- `/api-health`
- `/list room page:<number> page_size:<number>`
- `/list blend page:<number> page_size:<number>`
- `/rooms`
- `/room-create`
- `/room-info code:<CODE>`
- `/room-close code:<CODE> reason:<optional>`
- `/blend-info code:<CODE>`

The Discord OAuth integration is not a bot token and cannot receive or post
messages; the bot token must come from the Discord Developer Portal and be
stored in Replit Secrets.

The Node runtime is intentionally protocol-compatible with the Android client:
rooms use `POST /api/rooms` followed by `GET /room/<CODE>` with a WebSocket
upgrade. It also provides:

- `POST /api/blends` with `{ "username": "..." }`
- `POST /api/blends/<CODE>/join` with `{ "username": "..." }`
- `POST /api/blends/<CODE>/tracks` with `{ "username": "...", "track": { ... } }`
- `GET /api/blends/<CODE>`

Blends deduplicate submitted songs and rank them by the number of participants
who submitted each song. Track `id` values should be YouTube video IDs because
the Android client plays the returned playlist through YouTube Music.

The Node runtime stores rooms and blends in memory. Use the Durable Object
runtime below when you need hibernation and durable storage.

```bash
npm install
npx wrangler login      # browser auth, no card asked
npx wrangler deploy
```

You get `https://convx-sync.<subdomain>.workers.dev`. Put
`wss://convx-sync.<subdomain>.workers.dev` into the app under
**Settings → Integrations → Listen Together → custom server URL**.

Check it is alive:

```bash
curl https://convx-sync.<subdomain>.workers.dev/health   # {"ok":true}
```

Watch live logs while testing:

```bash
npx wrangler tail
```

## Billing

Free plan needs no card. If you stay on it there is no payment method on file,
so exceeding the daily request allowance rejects requests — it never produces a
bill. That is the main reason to prefer this over a VM.

**Verify before relying on it:** whether SQLite-backed Durable Objects are still
included on the Workers Free plan (dashboard → Workers & Pages → Plans). The
`wrangler.toml` here uses `new_sqlite_classes` for that reason. If DO has moved
to paid-only, the same design ports to Deno Deploy + Deno KV with no card.

## Config

`wrangler.toml` `[vars]`:

| Var | Default | Meaning |
|---|---|---|
| `ROOM_TTL_HOURS` | 6 | Room lifetime before it closes and deletes itself |
| `MAX_EXTENSIONS` | 2 | Times the owner may extend |
| `MAX_MEMBERS` | 20 | Per-room cap |

## Endpoints

- `POST /api/rooms` → `{ "room_code": "ABC123" }` — allocates a room
- `GET /room/<CODE>` with `Upgrade: websocket` → joins that room's DO
- `GET /health`

The client must call `POST /api/rooms` before opening the socket for a new
room, because the Worker has to know the code to pick a Durable Object and at
upgrade time it would not know it yet.

## Protocol notes

- **JSON only.** The Kotlin client starts in JSON uncompressed and permanently
  flips to protobuf + gzip if the server's first message is protobuf
  (`ListenTogetherClient.kt:783-785`). Never emit protobuf.
- Field names are snake_case to match the `@SerialName` annotations in
  `Protocol.kt`. A renamed field decodes as missing, not as an error.
- v2 adds `control_mode` (`owner` | `everyone`), `expires_at` and
  `extensions_used` to `RoomState`, plus `set_control_mode` / `extend_session`
  inbound and `control_mode_changed` / `room_expiring` / `room_closed` outbound.
  The Kotlin `Json` is configured with `ignoreUnknownKeys`, so older clients
  ignore the new fields instead of failing.

## Design constraints worth not breaking

**Hibernation.** Sockets are accepted with `state.acceptWebSocket()`, which lets
Cloudflare evict the object from memory while listeners are idle and keep the
connections open. That is what makes a quiet room free and removes the cold
start that makes Render/HF free tiers unusable for live sessions. The cost is
that class fields do not survive, so:

- room state lives in `storage`, reloaded in `blockConcurrencyWhile` on wake
- per-socket identity lives in `ws.serializeAttachment()`, not a `Map`
- deadlines use storage alarms, never `setTimeout`

Break any of those and it works in testing, then breaks the first time a room
goes quiet for a minute.

**Single alarm slot.** Room expiry, expiry warning, host grace and buffer
timeout all share one alarm; `rescheduleAlarm()` always arms the earliest.

## Edge cases handled

| Case | Behaviour |
|---|---|
| Host's screen locks | 90s grace before anyone else is promoted |
| Host leaves for good | Longest-connected member promoted, `host_changed` broadcast |
| Transfer host to someone who left | Rejected, room keeps a real host |
| Kicked user reconnects | Session token deleted on kick, so it fails |
| Duplicate socket after reconnect | Older socket closed, no double broadcasts |
| Room code collision | `/claim` returns 409, Worker retries a new code |
| One user never buffers | 10s timeout, room starts without them |
| Out-of-order playback messages | Anything older than `last_update` dropped |
| Clock skew | Server stamps `server_time` on every broadcast |
| Last member leaves | `storage.deleteAll()`, no leak |
| Abandoned room | TTL closes it, warning at T-10min |
| Room full | `join_rejected` with reason |

## No domain needed

`*.workers.dev` is free and comes with TLS, so `wss://` works with nothing
bought. The only thing a domain would add here is zone-level features — WAF
rate-limiting rules, firewall rules, per-zone analytics. Rate limiting is
handled in code instead (`src/guard.ts`), so none of that is required.

Two minor tradeoffs of staying on `workers.dev`: the hostname is long, and a
few corporate/ISP filters block the whole `workers.dev` domain because it has
been abused for phishing. Neither matters much for a music app. If you add a
domain later you can serve both hostnames at once, so existing users' saved
server URLs keep working.

## Not done yet

- Server-side blocklist. `blockedUsernames` is still client-only, so a blocked
  user currently rejoins fine from the server's point of view.
- Client changes: HTTP-then-socket connect flow, control-mode toggle, expiry
  countdown UI, and reconnect jitter (`ListenTogetherClient.kt:434` has none,
  so a redeploy makes every client retry in lockstep).
