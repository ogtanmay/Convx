"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.loadServerConfig = loadServerConfig;
const node_fs_1 = require("node:fs");
const node_path_1 = require("node:path");
function readConfigFile() {
    const path = process.env.CONVX_CONFIG_PATH?.trim() || (0, node_path_1.resolve)(process.cwd(), 'config.json');
    if (!(0, node_fs_1.existsSync)(path))
        return {};
    try {
        const parsed = JSON.parse((0, node_fs_1.readFileSync)(path, 'utf8'));
        return typeof parsed === 'object' && parsed !== null ? parsed : {};
    }
    catch (error) {
        console.error(`Convx config: unable to read ${path}:`, error);
        return {};
    }
}
function stringList(value) {
    if (!Array.isArray(value))
        return [];
    return value
        .filter((item) => typeof item === 'string')
        .map((item) => item.trim())
        .filter(Boolean);
}
function loadServerConfig() {
    const file = readConfigFile();
    const apiKeyEnv = file.api?.apiKeyEnv?.trim() || 'API_KEY';
    const botTokenEnv = file.discord?.botTokenEnv?.trim() || 'DISCORD_BOT_TOKEN';
    const adminUserIds = stringList(file.discord?.adminUserIds);
    return {
        apiKey: process.env[apiKeyEnv]?.trim() || '',
        discord: {
            botToken: process.env[botTokenEnv]?.trim() || '',
            guildId: file.discord?.guildId?.trim() || process.env.DISCORD_GUILD_ID?.trim() || '',
            adminUserIds: adminUserIds.length
                ? adminUserIds
                : (process.env.DISCORD_ADMIN_USER_IDS ?? '')
                    .split(',')
                    .map((id) => id.trim())
                    .filter(Boolean),
        },
    };
}