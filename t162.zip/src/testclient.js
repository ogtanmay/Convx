"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.TEST_CLIENT_HTML = void 0;
exports.TEST_CLIENT_HTML = `<!doctype html>
<html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Convx Sync — test member</title>
<style>
:root{color-scheme:dark}*{box-sizing:border-box}body{margin:0;font:15px/1.5 system-ui;background:#0b0b0f;color:#f2f2f7;padding:24px;max-width:760px;margin-inline:auto}
.card{background:#1c1c1e;border:1px solid #2c2c2e;border-radius:16px;padding:16px;margin-bottom:14px}label{display:block;font-size:12px;color:#8e8e93;margin:8px 0 4px}
input{width:100%;padding:11px;border-radius:11px;border:1px solid #3a3a3c;background:#2c2c2e;color:#fff}button{margin:12px 8px 0 0;padding:11px 16px;border:0;border-radius:11px;background:#0a84ff;color:#fff;font-weight:600}
pre{background:#000;border-radius:12px;padding:12px;max-height:320px;overflow:auto;font:12px/1.5 monospace}
</style></head><body><h1>Convx Sync — test member</h1>
<div class="card"><label>Room code</label><input id="code" placeholder="ABC123">
<label>Name</label><input id="name" value="browser"><button id="join">Join room</button><button id="leave" disabled>Leave</button></div>
<div class="card"><button class="act" data-a="play" disabled>Play</button><button class="act" data-a="pause" disabled>Pause</button>
<button class="act" data-a="skip_next" disabled>Next</button><pre id="log"></pre></div>
<script>
const $=s=>document.querySelector(s), logEl=$('#log'); let ws=null;
function log(dir,type,extra=''){logEl.textContent=new Date().toLocaleTimeString()+' '+dir+' '+type+' '+extra+'\\n'+logEl.textContent}
function send(type,payload){ws?.send(JSON.stringify(payload===undefined?{type}:{type,payload}));log('->',type)}
$('#join').onclick=()=>{const code=$('#code').value.trim().toUpperCase();if(!code)return;ws=new WebSocket(location.origin.replace(/^http/,'ws')+'/room/'+code);
ws.onopen=()=>{log('--','open');send('join_room',{username:$('#name').value||'browser'})};
ws.onclose=()=>{$('#leave').disabled=true;$('#join').disabled=false;document.querySelectorAll('.act').forEach(b=>b.disabled=true);log('--','closed')};
ws.onmessage=e=>{const m=JSON.parse(e.data);log('<-',m.type,m.payload?.reason||'');if(m.type==='join_approved'){$('#leave').disabled=false;$('#join').disabled=true;document.querySelectorAll('.act').forEach(b=>b.disabled=false)}};
};
$('#leave').onclick=()=>{send('leave_room');ws?.close()};document.querySelectorAll('.act').forEach(b=>b.onclick=()=>send('playback_action',{action:b.dataset.a,position:0,server_time:Date.now()}));
</script></body></html>`;