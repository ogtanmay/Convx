"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.startDiscordBot = startDiscordBot;
const discord_js_1 = require("discord.js");
const commands = [
    new discord_js_1.SlashCommandBuilder()
        .setName('api-health')
        .setDescription('Show the Convx API health and active resource counts'),
    new discord_js_1.SlashCommandBuilder()
        .setName('list')
        .setDescription('List API resources with pagination')
        .addSubcommand((subcommand) => subcommand
        .setName('room')
        .setDescription('List Listen Together rooms')
        .addIntegerOption((option) => option.setName('page').setDescription('Page number').setMinValue(1).setMaxValue(1000))
        .addIntegerOption((option) => option.setName('page_size').setDescription('Items per page').setMinValue(1).setMaxValue(10)))
        .addSubcommand((subcommand) => subcommand
        .setName('blend')
        .setDescription('List Blends')
        .addIntegerOption((option) => option.setName('page').setDescription('Page number').setMinValue(1).setMaxValue(1000))
        .addIntegerOption((option) => option.setName('page_size').setDescription('Items per page').setMinValue(1).setMaxValue(10))),
    new discord_js_1.SlashCommandBuilder()
        .setName('rooms')
        .setDescription('List active Listen Together rooms'),
    new discord_js_1.SlashCommandBuilder()
        .setName('room-create')
        .setDescription('Create an empty Listen Together room'),
    new discord_js_1.SlashCommandBuilder()
        .setName('room-info')
        .setDescription('Inspect one Listen Together room')
        .addStringOption((option) => option.setName('code').setDescription('Room code').setRequired(true).setMinLength(4).setMaxLength(12)),
    new discord_js_1.SlashCommandBuilder()
        .setName('room-close')
        .setDescription('Close a Listen Together room and disconnect its clients')
        .addStringOption((option) => option.setName('code').setDescription('Room code').setRequired(true).setMinLength(4).setMaxLength(12))
        .addStringOption((option) => option.setName('reason').setDescription('Reason shown to connected clients').setMaxLength(300)),
    new discord_js_1.SlashCommandBuilder()
        .setName('blend-info')
        .setDescription('Inspect one Blend')
        .addStringOption((option) => option.setName('code').setDescription('Blend code').setRequired(true).setMinLength(4).setMaxLength(12)),
].map((command) => command.toJSON());
function code(value) {
    return value.trim().toUpperCase();
}
function formatTime(timestamp) {
    return `<t:${Math.floor(timestamp / 1000)}:R>`;
}
function safeTrack(track) {
    return track ? `${track.title} — ${track.artist}` : 'Nothing playing';
}
function formatRoom(room) {
    const users = room.users.length
        ? room.users.map((user) => `${user.is_host ? '★ ' : ''}${user.username}${user.connected ? '' : ' (offline)'}`).join(', ')
        : 'No members';
    return [
        `**${room.code}** · ${room.members} member(s) · ${room.pending} pending`,
        `Playing: ${room.is_playing ? 'yes' : 'no'} · Track: ${safeTrack(room.current_track)}`,
        `Queue: ${room.queue_length} · Control: ${room.control_mode} · Expires: ${formatTime(room.expires_at)}`,
        `Users: ${users}`,
    ].join('\n');
}
function formatBlend(blend) {
    const topTrack = blend.tracks[0];
    return [
        `**${blend.code}** · ${blend.members.length} member(s) · ${blend.tracks.length} track(s)`,
        `Top track: ${topTrack ? `${topTrack.title} — ${topTrack.artist} (${topTrack.score})` : 'None'}`,
        `Created: ${formatTime(blend.created_at)}`,
    ].join('\n');
}
function pageValue(interaction, name, fallback) {
    return interaction.options.getInteger(name) ?? fallback;
}
function formatPage(label, items, page, pageSize, format) {
    const totalPages = Math.max(1, Math.ceil(items.length / pageSize));
    if (page > totalPages)
        return `${label}: page **${page}** does not exist. Choose a page from 1 to ${totalPages}.`;
    const start = (page - 1) * pageSize;
    const pageItems = items.slice(start, start + pageSize);
    return [
        `**${label}** · page ${page}/${totalPages} · ${items.length} total`,
        pageItems.length ? pageItems.map(format).join('\n\n') : 'No items.',
        totalPages > page ? `Run \`/list ${label === 'Rooms' ? 'room' : 'blend'} page:${page + 1}\` for more.` : 'End of list.',
    ].join('\n');
}
async function reply(interaction, content) {
    const clipped = content.length > 1900 ? `${content.slice(0, 1897)}...` : content;
    if (interaction.replied || interaction.deferred)
        await interaction.editReply(clipped);
    else
        await interaction.reply({ content: clipped, ephemeral: true });
}
async function handleCommand(interaction, api, config) {
    if (!config.adminUserIds.includes(interaction.user.id)) {
        await reply(interaction, 'You are not authorized to manage this API.');
        return;
    }
    switch (interaction.commandName) {
        case 'api-health': {
            const health = api.health();
            await reply(interaction, `API online. Active rooms: **${health.rooms}** · Blends: **${health.blends}** · Uptime: **${health.uptime_seconds}s**`);
            return;
        }
        case 'list': {
            const page = pageValue(interaction, 'page', 1);
            const pageSize = pageValue(interaction, 'page_size', 5);
            if (interaction.options.getSubcommand() === 'room')
                await reply(interaction, formatPage('Rooms', api.listRooms(), page, pageSize, formatRoom));
            else
                await reply(interaction, formatPage('Blends', api.listBlends(), page, pageSize, formatBlend));
            return;
        }
        case 'rooms': {
            const rooms = api.listRooms();
            await reply(interaction, rooms.length ? rooms.map(formatRoom).join('\n\n') : 'No active Listen Together rooms.');
            return;
        }
        case 'room-create': {
            const roomCode = api.createRoom();
            await reply(interaction, `Created room **${roomCode}**. Clients can now connect with this code.`);
            return;
        }
        case 'room-info': {
            const room = api.getRoom(code(interaction.options.getString('code', true)));
            await reply(interaction, room ? formatRoom(room) : 'Room not found.');
            return;
        }
        case 'room-close': {
            const roomCode = code(interaction.options.getString('code', true));
            const reason = interaction.options.getString('reason')?.trim() || 'Closed by Discord admin';
            await reply(interaction, api.closeRoom(roomCode, reason) ? `Closed room **${roomCode}**.` : `Room **${roomCode}** was not found.`);
            return;
        }
        case 'blend-info': {
            const blend = api.getBlend(code(interaction.options.getString('code', true)));
            if (!blend) {
                await reply(interaction, 'Blend not found.');
                return;
            }
            const tracks = blend.tracks.length
                ? blend.tracks.slice(0, 10).map((track, index) => `${index + 1}. ${track.title} — ${track.artist} (${track.score})`).join('\n')
                : 'No tracks submitted.';
            await reply(interaction, `**${blend.code}** · ${blend.members.length} member(s) · Created ${formatTime(blend.created_at)}\nTracks:\n${tracks}`);
            return;
        }
        default:
            await reply(interaction, 'Unknown management command.');
    }
}
async function startDiscordBot(api, config) {
    if (!config.botToken) {
        console.log('Discord bot: disabled (DISCORD_BOT_TOKEN is not configured)');
        return;
    }
    if (config.adminUserIds.length === 0) {
        console.error('Discord bot: disabled (DISCORD_ADMIN_USER_IDS must contain at least one user ID)');
        return;
    }
    const client = new discord_js_1.Client({ intents: [discord_js_1.GatewayIntentBits.Guilds] });
    const rest = new discord_js_1.REST({ version: '10' }).setToken(config.botToken);
    const application = await rest.get(discord_js_1.Routes.oauth2CurrentApplication());
    if (config.guildId)
        await rest.put(discord_js_1.Routes.applicationGuildCommands(application.id, config.guildId), { body: commands });
    else
        await rest.put(discord_js_1.Routes.applicationCommands(application.id), { body: commands });
    client.once(discord_js_1.Events.ClientReady, (readyClient) => {
        console.log(`Discord bot: connected as ${readyClient.user.tag}${config.guildId ? ` in guild ${config.guildId}` : ''}`);
    });
    client.on(discord_js_1.Events.InteractionCreate, (interaction) => {
        if (!interaction.isChatInputCommand())
            return;
        void handleCommand(interaction, api, config).catch((error) => {
            console.error('Discord command failed:', error);
            void reply(interaction, 'The command failed. Check the API server logs.');
        });
    });
    await client.login(config.botToken);
}